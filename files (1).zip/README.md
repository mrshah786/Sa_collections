```markdown
# SA Collection's — 3D eCommerce Static Site

This is a static, responsive 3D-enabled eCommerce demo for "SA Collection's" that showcases luxury watches, branded sunglasses and perfumes, with fast ordering via WhatsApp.

IMPORTANT: I have plugged in the WhatsApp number +91 87933 97317 into the JS so the "Order on WhatsApp" buttons open the correct chat.

## Files changed
- js/app.js — WhatsApp number set to 918793397317
- Added deployment workflow and Netlify config examples in `.github/workflows/deploy.yml` and `netlify.toml`

## How to deploy

Option A — GitHub Pages (automatic via Actions)
1. Create a new GitHub repository and push the project files (index.html, css/, js/, data/, assets/, etc.) to the `main` branch.
2. The included GitHub Actions workflow will automatically build and publish the repository root to the `gh-pages` branch whenever you push to `main`.
   - Ensure Actions are enabled for the repo.
   - After the action runs, enable Pages from the `gh-pages` branch in repo Settings → Pages (or use the default action behavior).
3. Visit `https://<your-username>.github.io/<repo-name>/` once GitHub Pages has finished.

Option B — Netlify (recommended for static sites)
1. Create a Netlify account and "New site from Git" → connect your GitHub repo.
2. Set publish directory to `/` (root).
3. Deploy. Netlify will provide a public URL; you can assign a custom domain later.

Option C — Manual / Local
- Serve via a static server locally:
  - Python: `python -m http.server 8000`
  - Node: `npx http-server -p 8000`
- Open `http://localhost:8000`

## GitHub Actions workflow
I included an example workflow (`.github/workflows/deploy.yml`) that publishes the site to `gh-pages` on every push to `main`. This means once you push your files, the action will run and deploy.

## Netlify config
I included a `netlify.toml` that sets the publish directory to the repository root.

## WhatsApp usage
- The app uses links like `https://wa.me/918793397317?text=...` — customers tap and open WhatsApp with a prefilled order message.
- If you'd like the message text changed (add address, payment preference, or language), tell me and I'll update it.

## Want me to push & deploy for you?
I can push these files and enable deployment automatically, but I need either:
- The GitHub repository name in `owner/repo` format where you'd like me to push (and permission to write), or
- You can push them yourself and follow the steps above.

Tell me which repo (owner/name) to push to, or say "I'll push" and I will provide the exact git commands to run locally.
```