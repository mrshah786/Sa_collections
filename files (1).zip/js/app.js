// App logic for SA Collection's demo store
// NOTE: WhatsApp business number plugged in below (country code, no +).
// Phone: +91 87933 97317 => use as 918793397317 in wa.me links.
const WHATSAPP_PHONE = "918793397317";

// DOM refs
const productsGrid = document.getElementById('productsGrid');
const searchInput = document.getElementById('searchInput');
const categoryFilter = document.getElementById('categoryFilter');
const yearSpan = document.getElementById('year');
const whatsAppCTA = document.getElementById('whatsAppCTA');

// Modal refs
const productModal = document.getElementById('productModal');
const modalClose = document.getElementById('modalClose');
const modalTitle = document.getElementById('modalTitle');
const modalSKU = document.getElementById('modalSKU');
const modalDesc = document.getElementById('modalDesc');
const modalImage = document.getElementById('modalImage');
const modalPrice = document.getElementById('modalPrice');
const variantWrap = document.getElementById('variantWrap');
const orderWhatsappBtn = document.getElementById('orderWhatsappBtn');
const threeCanvas = document.getElementById('threeCanvas');

let PRODUCTS = [];
let currentProduct = null;
let currentVariant = null;

// Basic Three.js viewer state
let renderer, scene, camera, model, loader, animateId;

function init(){
  yearSpan.textContent = new Date().getFullYear();
  whatsAppCTA.addEventListener('click', (e) => {
    e.preventDefault();
    // CTA opens WhatsApp general message
    const msg = encodeURIComponent("Hello SA Collection's! I need help choosing a product.");
    const href = `https://wa.me/${WHATSAPP_PHONE}?text=${msg}`;
    window.open(href, '_blank');
  });

  // Load products
  fetch('data/products.json')
    .then(r => r.json())
    .then(data => {
      PRODUCTS = data;
      renderProducts(PRODUCTS);
    });

  searchInput.addEventListener('input', applyFilters);
  categoryFilter.addEventListener('change', applyFilters);
  modalClose.addEventListener('click', closeModal);
  productModal.addEventListener('click', (e)=> { if(e.target === productModal) closeModal(); });
}

// Filter and render
function applyFilters(){
  const q = searchInput.value.trim().toLowerCase();
  const cat = categoryFilter.value;
  const filtered = PRODUCTS.filter(p => {
    const inCat = (cat === 'all') ? true : p.category === cat;
    const inQuery = p.name.toLowerCase().includes(q) || (p.tags && p.tags.join(' ').toLowerCase().includes(q));
    return inCat && inQuery;
  });
  renderProducts(filtered);
}

function renderProducts(list){
  productsGrid.innerHTML = '';
  list.forEach(p => {
    const card = document.createElement('article');
    card.className = 'card';
    card.innerHTML = `
      <img src="${p image ? p.image : 'assets/placeholder-watch.jpg'}" alt="${p.name}" loading="lazy" />
      <div>
        <div class="title">${p.name}</div>
        <div class="meta">${p.brand} • ${p.category}</div>
        <div class="price">${formatPrice(p.price)}</div>
      </div>
    `;
    card.addEventListener('click', ()=> openProduct(p.id));
    productsGrid.appendChild(card);
  });
}

function openProduct(id){
  const p = PRODUCTS.find(x => x.id === id);
  if(!p) return;
  currentProduct = p;
  currentVariant = p.variants && p.variants[0] ? p.variants[0] : null;

  modalTitle.textContent = p.name;
  modalSKU.textContent = `SKU: ${p.sku}`;
  modalDesc.textContent = p.description;
  modalPrice.textContent = formatPrice(p.price);
  modalImage.src = p.image;
  modalImage.alt = p.name;

  // variants
  variantWrap.innerHTML = '';
  if(p.variants && p.variants.length){
    p.variants.forEach((v, idx) => {
      const b = document.createElement('button');
      b.className = 'variant' + (idx===0 ? ' active' : '');
      b.textContent = v.name;
      b.addEventListener('click', ()=> {
        document.querySelectorAll('.variant').forEach(el=>el.classList.remove('active'));
        b.classList.add('active');
        currentVariant = v;
        updateWhatsappLink();
      });
      variantWrap.appendChild(b);
    });
  }

  // WhatsApp order link
  updateWhatsappLink();

  // Show 3D model if available
  if((p.model && p.model.endsWith('.gltf')) || (p.model && p.model.endsWith('.glb'))){
    modalImage.style.display = 'none';
    threeCanvas.style.display = 'block';
    initThreeViewer(p.model);
  } else {
    // no 3D model: show image fallback
    if(renderer) disposeThree();
    threeCanvas.style.display = 'none';
    modalImage.style.display = 'block';
  }

  productModal.setAttribute('aria-hidden','false');
  productModal.style.display = 'flex';
}

// Close modal and cleanup three
function closeModal(){
  productModal.setAttribute('aria-hidden','true');
  productModal.style.display = 'none';
  if(renderer) disposeThree();
}

// Format price
function formatPrice(n){
  return typeof n === 'number' ? '₹' + n.toLocaleString() : n;
}

function updateWhatsappLink(){
  const p = currentProduct;
  if(!p) return;
  const variantText = currentVariant ? `Variant: ${currentVariant.name}\n` : '';
  const msg = `Hi SA Collection's,\nI'd like to order:\nProduct: ${p.name}\nSKU: ${p.sku}\n${variantText}Price: ${formatPrice(p.price)}\nPlease confirm availability and shipping.\nMy Name: \nPhone: `;
  const href = `https://wa.me/${WHATSAPP_PHONE}?text=${encodeURIComponent(msg)}`;
  orderWhatsappBtn.href = href;
}

// Three.js viewer (simple orbital with auto-rotate)
function initThreeViewer(modelUrl){
  const width = threeCanvas.clientWidth || 420;
  const height = 420;

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x071021);

  camera = new THREE.PerspectiveCamera(35, width/height, 0.1, 1000);
  camera.position.set(0, 1.4, 3);

  renderer = new THREE.WebGLRenderer({canvas: threeCanvas, antialias:true, alpha:true});
  renderer.setSize(width, height);
  renderer.setPixelRatio(Math.min(window.devicePixelRatio,2));

  const hemi = new THREE.HemisphereLight(0xffffff, 0x444444, 0.7);
  scene.add(hemi);
  const dir = new THREE.DirectionalLight(0xffffff, 0.8);
  dir.position.set(5,10,7);
  scene.add(dir);

  loader = new THREE.GLTFLoader();
  loader.load(modelUrl, (gltf) => {
    model = gltf.scene;
    // Fit model
    const box = new THREE.Box3().setFromObject(model);
    const size = box.getSize(new THREE.Vector3());
    const maxDim = Math.max(size.x, size.y, size.z);
    const scale = 1.2 / maxDim;
    model.scale.set(scale, scale, scale);
    model.position.set(0, -0.6, 0);
    scene.add(model);
  }, undefined, (err)=> {
    console.warn('3D model failed to load', err);
    // fallback to static image
    threeCanvas.style.display='none';
    modalImage.style.display='block';
  });

  // simple auto-rotate
  let angle = 0;
  function animate(){
    animateId = requestAnimationFrame(animate);
    angle += 0.004;
    if(model) model.rotation.y = angle;
    renderer.render(scene,camera);
  }
  animate();
}

// dispose three
function disposeThree(){
  cancelAnimationFrame(animateId);
  if(scene && model) scene.remove(model);
  if(renderer) { renderer.dispose(); renderer.forceContextLoss(); renderer = null; }
  scene = null; camera = null; model = null; loader = null;
  threeCanvas.width = threeCanvas.height = 0;
}

// Initialize app
init();